---
name: manus-markdown-guard
description: Guardrail-Workflow für externe KI (insb. Manus), damit Unit-Markdown-Dateien parser-/import-kompatibel bleiben (Unique Vocabulary Keys, **Instructions:** Pflicht, Options-Format A)/B)/C)/D), Blanks als _____, Drinks-Logik „Sok od …“). Verwenden wenn der Nutzer Manus erwähnt, neue Unit-Markdown-Dateien generiert, oder Import/Parser-Errors wie Duplicate Vocabulary oder missing options auftreten.
---

# Manus Markdown Guard (Serbian Tutor)

## Ziel
Diese Anleitung standardisiert das Vorgehen, wenn Unit-Markdown über eine externe KI (z.B. Manus) generiert wird und unser Import/Parser sonst durch **Format-Rewrites** oder **Semantik-Fehler** (Drinks vs. Fruits) „zerschossen“ wird.

## Quick Start
- **Prompt-Quelle**: Nutze den aktuellen Repo-Prompt unter `docs/KI Regel/external-ai-markdown-unit-prompt.v7.md`.
- **Wenn der Nutzer Parser-Errors postet**: Mappe die Fehler auf diese 3 Hauptursachen:
  - **Duplicate Vocabulary** (gleicher Serbian-Key mehrfach in Vokabel-Tabellen)
  - **Options nicht parsebar** (komma-separiert statt `A) ...  B) ...`)
  - **Exercise-Block unvollständig** (`**Instructions:**` fehlt, `Options` fehlt in ex3/ex5, falsches Blank-Format)

## Manus-spezifische Leitplanken (wichtig)
Wenn Manus „optimiert“, werden typischerweise Tabellen/Spalten/Optionen verändert. Erzwinge deshalb:
- **Keine Reformatierung**: Tabellenzeilen nicht umbrechen, Spalten nicht umordnen, keine Auto-Listen.
- **Blanks**: ausschließlich `_____` (fünf Unterstriche), nicht `[ ]`, nicht `___`, nicht `…`.
- **Options**: niemals Kommas als Trenner; immer `A) ...  B) ...  C) ...  D) ...`.

## Inhaltliche Logik (kritisch): Drinks vs. Fruits
Verhindert die häufigste semantische Fehlgenerierung:
- In einem „Drinks“-Kontext gehören **Säfte**, nicht die **Frucht als Getränk**.
  - **Falsch**: `Jabuka` in Drinks
  - **Richtig**: `Sok od jabuke` in Drinks
- Früchte wie `Jabuka` gehören in Fruits/Market/Shopping-Kontext, nicht als Getränk.

## Validierungs-Checkliste (für Review/Debug)
Prüfe bei einer neuen Unit-Markdown-Datei systematisch:
- **Vocabulary**
  - Tabellen exakt: `| Serbian | English | Notes |` + Separator
  - Serbian-Keys global eindeutig (keine Duplikate über Kategorien hinweg)
  - **Polysemie-Regel (hart)**: ein Serbian-Key = **genau eine** Zeile (nicht „eine Zeile pro Bedeutung“)
    - zusätzliche Bedeutungen/Verwendungen gehören in Notes als `AlsoMeaning: ...` / `Usage: ...` / `Context: ...`
  - Serbian „audio-clean“ (keine `()[]/*` oder `.?!,:;`)
- **Exercises**
  - Unter jeder `### Exercise X: ...` steht eine Zeile: `**Instructions:** ...`
  - Jede Exercise-Tabelle hat **Question ID** als **erste Spalte** (nie leer)
  - IDs sind stabil und im Format `u<UNIT>_ex<EX>_q<NN>` (keine Random IDs, nicht bei Rewrite neu generieren)
  - ex3 + ex5 haben eine `Options`-Spalte und **jede Zeile** hat **3–4** Optionen im Format `A) ...  B) ...  C) ...  D) ...`
    - **Options dürfen niemals leer sein** (auch nicht bei Dialogue Completion)
  - `Answer (for database)` matcht exakt eine Option (nach Entfernen des Prefix A)/B)/C)/D))
  - Fill-in-the-Blank & Dialogue blanks sind genau `_____`
- **Cultural Note**
  - Überschrift muss als eigenes H2-Heading in einer Zeile stehen, z.B. `## 6. Cultural Note: <Title>` (oder `## C. Cultural Note: ...` / `## Cultural Note: ...`)
  - KEIN „Heading-Mix“ wie `Cultural Note: ### <Title>` in einer Zeile
  - Subheadings innerhalb der Cultural Note sind ok, aber separat in eigener Zeile: `### <Subtopic>`
- **Coverage**
  - Alles Serbian in Phrases/Dialogues/Exercises ist in Vocabulary enthalten oder `KnownFrom: Unit <n>` markiert

## Typische Reparatur-Anweisungen (für den Nutzer / Manus)
Wenn der Nutzer mit Manus arbeitet, gib klare Repair-Tasks, z.B.:
- **Duplicate Vocabulary / Polysemie (harte Regel)**:
  - „Jeder Serbian-Key darf in der Vocabulary exakt **einmal** vorkommen (global).“
  - „Wenn ein Wort mehrere Bedeutungen/Verwendungen hat: **keine zweite Zeile** erstellen.“
  - „Behalte genau eine Zeile, setze eine primäre Bedeutung in die English-Spalte und schreibe alle weiteren in Notes, z.B. `AlsoMeaning: ...; Usage: ...; Context: ...`.“
- **Komma-Options**: „Schreibe Optionen um zu `A) …  B) …  C) …  D) …`; keine Kommas als Separator.“
- **Question IDs fehlen/instabil**:
  - „Füge in JEDER Exercise-Tabelle eine erste Spalte `Question ID` hinzu.“
  - „Nutze Format `u<UNIT>_ex<EX>_q<NN>` und ändere bestehende IDs bei Rewrites nicht.“
- **ex5 ohne Optionen (harte Regel)**:
  - „Fülle **jede** ex5-Zeile mit 3–4 Optionen im Format `A) ...  B) ...  C) ...  D) ...` (niemals leer).“
  - „Wenn Distraktoren fehlen: erfinde plausible Distraktoren aus der vorhandenen Unit-Vocabulary (z.B. Fragewörter wie `Gde`, `Šta`, `Kako`, `Koliko`; häufige Wörter wie `Još`, `Molim`, `Hvala`; oder semantisch ähnliche Nomen wie `hleb`, `sir`, `voda`).“
  - „Setze `Answer (for database)` so, dass es **exakt** eine Option matcht (empfohlen: lettered Form wie `A) Koliko`).“
- **Drinks-Logik**: „Ersetze `Jabuka`/`Pomorandža` in Drinks durch `Sok od jabuke`/`Sok od pomorandže` und passe Übungen/Phrasen entsprechend an.“
- **Cultural Note Heading kaputt**:
  - „Schreibe die Cultural Note als eigenes H2-Heading, z.B. `## 6. Cultural Note: Food Culture in Serbia and Montenegro`.“
  - „Schreibe NICHT `Cultural Note: ### Food Culture ...` in einer Zeile.“

## Output-Regel (für externe KI)
Fordere bei Manus/externen KIs konsequent:
- **Nur das finale Markdown** auszugeben (keine Meta-Kommentare, keine Erklärtexte).
- Bei Unklarheiten lieber „INVALID_OUTPUT“ statt halbgarem Markdown (wenn der Flow das erlaubt).

## Minimaler "Fail-Fast" Hinweis (für Manus)
Wenn der Nutzer dir Validator-Fehler nennt (z.B. „Duplicate Serbian entry“ oder „multipleChoice must have at least 2 options“):
- Behandle das als **Blocker**: Ausgabe gilt erst als fertig, wenn diese Klassen behoben sind.

## Hinweis: Prompt-Version
Wenn du auf den Repo-Prompt verweist, nenne den Pfad. Für die Versionierung nutzen wir `external-ai-markdown-unit-prompt.v7.md` (und nicht „v7 liegt in v4“).

